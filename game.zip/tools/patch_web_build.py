#!/usr/bin/env python3
"""
patch_web_build.py — Echo Yonder Web 包自动注入脚本

每次 Ren'Py 重新打 Web 包后运行此脚本，自动：
  1. 把 ai_bridge.js 复制到 Web 包输出目录。
  2. 在 Web 包的 index.html 中插入 <script src="ai_bridge.js"></script>。
  3. 覆盖 #inputDiv 的 CSS，将输入框从顶部移到底部。
  4. 幂等操作：已注入则跳过，不重复插入。

用法：
    python tools/patch_web_build.py <Web包目录> [JS文件路径]

示例：
    python tools/patch_web_build.py D:\\Build\\EchoYonder-web
    python tools/patch_web_build.py D:\\Build\\EchoYonder-web D:\\Code\\Echo-Yonder\\web_custom\\ai_bridge.js
"""

import argparse
import shutil
import sys
from pathlib import Path

# 默认 JS 文件路径（相对于本脚本所在目录的上级，即项目根目录）
_SCRIPT_DIR = Path(__file__).resolve().parent
_DEFAULT_JS_PATH = _SCRIPT_DIR.parent / "web_custom" / "ai_bridge.js"

# ── 注入标记（用于幂等检测） ────────────────────────────────────────────────
_SCRIPT_TAG    = '<script src="ai_bridge.js"></script>'
_CSS_MARKER    = "/* echo-yonder-patch: inputDiv fix */"
_INJECT_BEFORE = "</body>"

# ── 覆盖 #inputDiv 位置的 CSS（注入到 <style> 末尾前） ─────────────────────
_INPUT_DIV_CSS = """\
    {marker}
    #inputDiv {{
      top: auto !important;
      bottom: 15% !important;
      border-radius: 5px 5px 0 0 !important;
    }}
""".format(marker=_CSS_MARKER)

def patch(web_dir: Path, js_src: Path) -> None:
    if not web_dir.is_dir():
        print(f"[ERROR] Web 包目录不存在: {web_dir}")
        sys.exit(1)

    if not js_src.is_file():
        print(f"[ERROR] JS 文件不存在: {js_src}")
        sys.exit(1)

    # 先验证 index.html，再复制文件。这样传错目录时不会留下"只复制了一半"的产物。
    index_html = web_dir / "index.html"
    if not index_html.is_file():
        print(f"[ERROR] index.html 不存在: {index_html}")
        sys.exit(1)

    # ── Step 1：复制 JS 文件 ────────────────────────────────────────────────
    js_dest = web_dir / "ai_bridge.js"
    shutil.copy2(js_src, js_dest)
    print(f"[OK] 已复制: {js_src} → {js_dest}")

    # ── Step 2：读取 index.html ─────────────────────────────────────────────
    content = index_html.read_text(encoding="utf-8")
    modified = False

    # ── Step 3：注入 #inputDiv CSS 覆盖 ────────────────────────────────────
    if _CSS_MARKER in content:
        print("[SKIP] #inputDiv CSS 已注入，跳过。")
    else:
        if "</style>" in content:
            content = content.replace("</style>", _INPUT_DIV_CSS + "  </style>", 1)
            print("[OK] 已注入 #inputDiv 位置修复 CSS。")
            modified = True
        else:
            print("[WARN] index.html 中未找到 </style>，跳过 CSS 注入。")

    # ── Step 4：注入 ai_bridge.js script 标签 ──────────────────────────────
    if _SCRIPT_TAG in content:
        print('[SKIP] index.html 中已存在 <script src="ai_bridge.js">，跳过注入。')
    else:
        if _INJECT_BEFORE in content:
            content = content.replace(
                _INJECT_BEFORE,
                f"    {_SCRIPT_TAG}\n{_INJECT_BEFORE}",
                1,
            )
        else:
            content = content + "\n" + _SCRIPT_TAG + "\n"
        print(f"[OK] 已注入 {_SCRIPT_TAG}。")
        modified = True

    # ── Step 5：写回 ────────────────────────────────────────────────────────
    if modified:
        index_html.write_text(content, encoding="utf-8")
        print(f"[OK] index.html 已更新: {index_html}")
    else:
        print("[INFO] index.html 无需修改。")


def main() -> None:
    parser = argparse.ArgumentParser(
        description="将 ai_bridge.js 注入到 Ren'Py Web 包的 index.html 中。"
    )
    parser.add_argument(
        "web_dir",
        help="Ren'Py Web 包输出目录（包含 index.html 的目录）",
    )
    parser.add_argument(
        "js_file",
        nargs="?",
        default=str(_DEFAULT_JS_PATH),
        help=f"ai_bridge.js 源文件路径（默认：{_DEFAULT_JS_PATH}）",
    )
    args = parser.parse_args()

    patch(Path(args.web_dir).resolve(), Path(args.js_file).resolve())
    print("[DONE] patch_web_build 执行完毕。")


if __name__ == "__main__":
    main()
