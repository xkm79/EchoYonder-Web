@echo off
setlocal EnableExtensions EnableDelayedExpansion

set "NO_PAUSE="
if /I "%~1"=="--no-pause" set "NO_PAUSE=1"

set "RENPY_SDK=D:\renpy-8.5.2-sdk"
for %%I in ("%~dp0..") do set "PROJECT_DIR=%%~fI"
set "DIST_DIR=D:\Code\EchoYonder-1.0-dists"
set "BUILD_DIR=%DIST_DIR%\EchoYonder-1.0-web"
set "RELEASE_DIR=D:\Code\echo-yonder-web-release"
set "JS_FILE=%PROJECT_DIR%\web_custom\ai_bridge.js"

echo.
echo Checking prerequisites...
if not exist "%RENPY_SDK%\renpy.exe" (
    echo [ERROR] Ren'Py executable not found: %RENPY_SDK%\renpy.exe
    if not defined NO_PAUSE pause
    exit /b 1
)
if not exist "%JS_FILE%" (
    echo [ERROR] JavaScript bridge not found: %JS_FILE%
    if not defined NO_PAUSE pause
    exit /b 1
)
if not exist "%RELEASE_DIR%\.git" (
    echo [ERROR] Release directory is not a Git repository: %RELEASE_DIR%
    echo         Synchronization stopped to protect against a wrong target.
    if not defined NO_PAUSE pause
    exit /b 1
)

echo [OK] Ren'Py SDK:  %RENPY_SDK%
echo [OK] Project:     %PROJECT_DIR%
echo [OK] Build:       %BUILD_DIR%
echo [OK] Release:     %RELEASE_DIR%

echo.
echo [1/4] Building the Ren'Py Web distribution...
if exist "%BUILD_DIR%" (
    echo       Removing old build: %BUILD_DIR%
    rmdir /s /q "%BUILD_DIR%"
)
if exist "%DIST_DIR%\EchoYonder-1.0-web.zip" (
    del /q "%DIST_DIR%\EchoYonder-1.0-web.zip"
)

"%RENPY_SDK%\renpy.exe" "%RENPY_SDK%\launcher" web_build "%PROJECT_DIR%" --destination "%BUILD_DIR%"
if errorlevel 1 (
    set "BUILD_EXIT=!errorlevel!"
    echo.
    echo [ERROR] Ren'Py Web build failed with exit code !BUILD_EXIT!.
    if not defined NO_PAUSE pause
    exit /b !BUILD_EXIT!
)
if not exist "%BUILD_DIR%\index.html" (
    echo [ERROR] Build finished without index.html: %BUILD_DIR%
    if not defined NO_PAUSE pause
    exit /b 1
)
echo [OK] Web distribution created.

echo.
echo [2/4] Removing development-only files...
powershell -NoProfile -Command ^
  "& { ^
    $build = '%BUILD_DIR%'; ^
    $removed = 0; ^
    $patterns = @( ^
      'game\*.rpy', ^
      'game\*.rpym', ^
      'game\tl\None\*', ^
      'game\saves\*', ^
      'game\cache\*', ^
      'game\renpy_warp_*.rpe.py', ^
      'game\libs\vscode_renpy_warp_*.rpe.py', ^
      'game\libs\libs.txt', ^
      'game\**\*.bak', ^
      'game\**\*.new', ^
      'game\**\*.old' ^
    ); ^
    foreach ($pattern in $patterns) { ^
      $recurse = $pattern.Contains('**'); ^
      $items = Get-ChildItem -Path (Join-Path $build $pattern) -ErrorAction SilentlyContinue -Recurse:$recurse; ^
      foreach ($item in $items) { ^
        Remove-Item -LiteralPath $item.FullName -Recurse -Force -ErrorAction SilentlyContinue; ^
        Write-Host ('  [DEL] ' + $item.FullName.Replace($build + '\', '')); ^
        $removed++ ^
      } ^
    }; ^
    $emptyDirs = @('game\tl\None', 'game\prompts', 'game\saves', 'game\cache', 'game\libs'); ^
    foreach ($directory in $emptyDirs) { ^
      $full = Join-Path $build $directory; ^
      if ((Test-Path -LiteralPath $full) -and -not (Get-ChildItem -LiteralPath $full -ErrorAction SilentlyContinue)) { ^
        Remove-Item -LiteralPath $full -Recurse -Force -ErrorAction SilentlyContinue; ^
        Write-Host ('  [DEL] ' + $directory + ' (empty)') ^
      } ^
    }; ^
    Write-Host ('  Removed items: ' + $removed) ^
  }"
if errorlevel 1 (
    echo [WARN] Some cleanup operations failed. Review the output above.
)
echo [OK] Build cleanup completed.

echo.
echo [3/4] Patching the Web distribution...
python "%PROJECT_DIR%\tools\patch_web_build.py" "%BUILD_DIR%" "%JS_FILE%"
if errorlevel 1 (
    set "PATCH_EXIT=!errorlevel!"
    echo [ERROR] Web patch failed with exit code !PATCH_EXIT!.
    if not defined NO_PAUSE pause
    exit /b !PATCH_EXIT!
)

echo.
echo [4/4] Synchronizing the release repository...
echo       FROM: %BUILD_DIR%
echo       TO:   %RELEASE_DIR%
robocopy "%BUILD_DIR%" "%RELEASE_DIR%" /MIR /NFL /NDL /NJH /NJS /XJ /XD ".git" "%RELEASE_DIR%\.git" /XF "README*" "readme*"
if errorlevel 8 (
    set "COPY_EXIT=!errorlevel!"
    echo [ERROR] Release synchronization failed with exit code !COPY_EXIT!.
    if not defined NO_PAUSE pause
    exit /b !COPY_EXIT!
)
if not exist "%RELEASE_DIR%\.git" (
    echo [ERROR] Release repository .git is missing after synchronization.
    if not defined NO_PAUSE pause
    exit /b 1
)
echo [OK] Release synchronized and .git preserved.

echo.
echo ============================================================
echo  Build completed: %RELEASE_DIR%
echo ============================================================
echo.
if not defined NO_PAUSE pause
exit /b 0
