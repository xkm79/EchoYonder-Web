@echo off
setlocal EnableDelayedExpansion
chcp 65001 > nul

rem ============================================================
rem deploy_web.bat - Echo Yonder Web 一键构建脚本
rem
rem 功能：
rem   1. 调用 Ren'Py SDK 自动打 Web 包
rem   2. 清理 Web 包中不需要的文件（.rpy 源码、备份、开发工具等）
rem   3. 用 patch_web_build.py 注入 ai_bridge.js 到 Web 包
rem   4. 用 robocopy 同步到 Web 发行版目录
rem
rem 用法：
rem   直接双击运行，或在命令行执行：
rem     tools\deploy_web.bat
rem ============================================================

rem ── 配置区（按实际情况修改） ──────────────────────────────────────────────

rem Ren'Py SDK 根目录
set "RENPY_SDK=D:\renpy-8.5.2-sdk"

rem 本项目根目录（脚本所在目录的上一级）
for %%I in ("%~dp0..") do set "PROJECT_DIR=%%~fI"

rem Ren'Py 打包输出目录
set "DIST_DIR=D:\Code\EchoYonder-1.0-dists"

rem 打包完成后 Web 包所在子目录
set "BUILD_DIR=%DIST_DIR%\EchoYonder-1.0-web"

rem Web 发行版目录（用于版本管理）
set "RELEASE_DIR=D:\Code\echo-yonder-web-release"

rem ai_bridge.js 源文件路径
set "JS_FILE=%PROJECT_DIR%\web_custom\ai_bridge.js"

rem 注意：下方会删除旧 BUILD_DIR，并用 robocopy /MIR 镜像 RELEASE_DIR。
rem /MIR 会删除 RELEASE_DIR 中不存在于新构建里的文件，但排除 .git 目录和 README 文件。
rem 修改路径后务必先确认输出内容。

rem ── 检查前置条件 ───────────────────────────────────────────────────────────
echo.
echo 检查前置条件...
if not exist "%RENPY_SDK%\renpy.exe" (
    echo [ERROR] 未找到 renpy.exe: %RENPY_SDK%\renpy.exe
    pause
    exit /b 1
)
if not exist "%JS_FILE%" (
    echo [ERROR] ai_bridge.js 不存在: %JS_FILE%
    pause
    exit /b 1
)
echo [OK] Ren'Py SDK: %RENPY_SDK%
echo [OK] 项目目录:   %PROJECT_DIR%
echo [OK] 打包输出:   %BUILD_DIR%
echo [OK] 发行版目录: %RELEASE_DIR%

rem ── Step 1：调用 Ren'Py 打 Web 包 ──────────────────────────────────────────
echo.
echo [1/4] 开始 Ren'Py Web 打包（这可能需要几分钟）...

rem 清除旧包，确保每次都重新构建
if exist "%BUILD_DIR%" (
    echo       清除旧 Web 包: %BUILD_DIR%
    rmdir /s /q "%BUILD_DIR%"
)
if exist "%DIST_DIR%\EchoYonder-1.0-web.zip" (
    del /q "%DIST_DIR%\EchoYonder-1.0-web.zip"
)
echo.

"%RENPY_SDK%\renpy.exe" "%RENPY_SDK%\launcher" web_build "%PROJECT_DIR%" --destination "%BUILD_DIR%"

if errorlevel 1 (
    echo.
    echo [ERROR] Ren'Py Web 构建失败，退出码: %errorlevel%
    pause
    exit /b 1
)

if not exist "%BUILD_DIR%\index.html" (
    echo [ERROR] 打包完成但未找到 index.html: %BUILD_DIR%
    echo         请检查 %DIST_DIR% 下实际生成的文件夹名称，并修改脚本中的 BUILD_DIR。
    pause
    exit /b 1
)
echo [OK] Web 包已生成: %BUILD_DIR%

rem ── Step 2：清理 Web 包中不需要的文件（减小包体） ──────────────────────────
echo.
echo [2/4] 清理 Web 包中不需要的文件...

rem Ren'Py web_build 产物里通常包含 game/ 目录下的完整内容（含源码 .rpy）。
rem 以下 PowerShell 命令删除不需要出现在 Web 包里的内容。

powershell -NoProfile -Command ^
  "& { ^
    $build = '%BUILD_DIR%'; ^
    $removed = 0; ^
    $patterns = @( ^
      'game\*.rpy', ^
      'game\*.rpym', ^
      'game\tl\None\*', ^
      'game\saves\*', ^
      'game\cache\*', ^
      'game\renpy_warp_*.rpe.py', ^
      'game\libs\vscode_renpy_warp_*.rpe.py', ^
      'game\libs\libs.txt', ^
      'game\**\*.bak', ^
      'game\**\*.new', ^
      'game\**\*.old' ^
    ); ^
    foreach ($pat in $patterns) { ^
      $items = Get-ChildItem -Path (Join-Path $build $pat) -ErrorAction SilentlyContinue -Recurse:($pat -like '**\**'); ^
      foreach ($item in $items) { ^
        Remove-Item -Path $item.FullName -Recurse -Force -ErrorAction SilentlyContinue; ^
        Write-Host ('  [DEL] ' + $item.FullName.Replace($build + '\', '')); ^
        $removed++ ^
      } ^
    }; ^
    $emptyDirs = @('game\tl\None', 'game\prompts', 'game\saves', 'game\cache', 'game\libs'); ^
    foreach ($d in $emptyDirs) { ^
      $full = Join-Path $build $d; ^
      if (Test-Path $full) { ^
        $children = Get-ChildItem $full -ErrorAction SilentlyContinue; ^
        if (-not $children) { ^
          Remove-Item $full -Recurse -Force -ErrorAction SilentlyContinue; ^
          Write-Host ('  [DEL] ' + $d + ' (empty dir)') ^
        } ^
      } ^
    }; ^
    Write-Host ('  共清理 ' + $removed + ' 个文件/目录') ^
  }"

if errorlevel 1 (
    echo [WARN] 部分清理步骤失败，继续构建但请检查上面的输出。
)
echo [OK] Web 包清理完成。

rem ── Step 3：注入 ai_bridge.js ───────────────────────────────────────────────
echo.
echo [3/4] 注入 ai_bridge.js 到 Web 包...
python "%PROJECT_DIR%\tools\patch_web_build.py" "%BUILD_DIR%" "%JS_FILE%"
if errorlevel 1 (
    echo [ERROR] patch_web_build.py 执行失败。
    pause
    exit /b 1
)

rem ── Step 4：同步到发行版目录 ────────────────────────────────────────────────
echo.
echo [4/4] 同步到发行版目录...
echo       FROM: %BUILD_DIR%
echo       TO:   %RELEASE_DIR%

if not exist "%RELEASE_DIR%" (
    mkdir "%RELEASE_DIR%"
    echo [OK] 已创建发行版目录: %RELEASE_DIR%
)

robocopy "%BUILD_DIR%" "%RELEASE_DIR%" /MIR /NFL /NDL /NJH /NJS /XD ".git" /XF "README*" "readme*"
if errorlevel 8 (
    echo [ERROR] robocopy 同步失败，退出码: %errorlevel%
    pause
    exit /b 1
)
echo [OK] 同步完成。

rem ── 完成 ────────────────────────────────────────────────────────────────────
echo.
echo ============================================================
echo  构建完成！
echo  Web 发行版位于: %RELEASE_DIR%
echo ============================================================
echo.
pause
