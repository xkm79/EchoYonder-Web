@echo off
setlocal EnableExtensions EnableDelayedExpansion

set "NO_PAUSE="
if /I "%~1"=="--no-pause" set "NO_PAUSE=1"

set "DEPLOY_SCRIPT=%~dp0deploy_web.bat"
set "TEST_SCRIPT=%~dp0test_web_build.py"

echo.
echo ============================================================
echo  Echo Yonder Web Build and Test
echo ============================================================
echo.

if not exist "%DEPLOY_SCRIPT%" (
    echo [ERROR] Missing deploy script: %DEPLOY_SCRIPT%
    if not defined NO_PAUSE pause
    exit /b 1
)

if not exist "%TEST_SCRIPT%" (
    echo [ERROR] Missing test script: %TEST_SCRIPT%
    if not defined NO_PAUSE pause
    exit /b 1
)

where python >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python was not found on PATH.
    if not defined NO_PAUSE pause
    exit /b 1
)

echo [1/2] Building and synchronizing the Web release...
echo.
call "%DEPLOY_SCRIPT%" --no-pause
if errorlevel 1 (
    set "DEPLOY_EXIT=!errorlevel!"
    echo.
    echo [ERROR] Web build failed with exit code !DEPLOY_EXIT!.
    echo         See the first [ERROR] above for the cause.
    echo.
    if not defined NO_PAUSE pause
    exit /b !DEPLOY_EXIT!
)

echo.
echo [2/2] Starting the local test server...
echo.
python "%TEST_SCRIPT%"
if errorlevel 1 (
    set "TEST_EXIT=!errorlevel!"
    echo.
    echo [ERROR] Test server failed with exit code !TEST_EXIT!.
    echo.
    if not defined NO_PAUSE pause
    exit /b !TEST_EXIT!
)

exit /b 0
