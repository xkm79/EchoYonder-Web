#!/usr/bin/env python3
"""
test_web_build.py — Echo Yonder Web 构建后测试辅助脚本

功能：
  1. 在 Web 发行版目录启动本地 HTTP 服务（默认端口 8765）
  2. 在浏览器中打开 ?clear_persistent=1，请求 Ren'Py 调用 persistent._clear()
  3. 游戏页面随即自动加载，可在浏览器中进行测试

用法：
    python tools/test_web_build.py [--port PORT] [--release-dir DIR]

示例：
    python tools/test_web_build.py
    python tools/test_web_build.py --port 9000
"""

import argparse
import http.server
import os
import sys
import threading
import webbrowser
from pathlib import Path

# ── 默认路径配置（与 deploy_web.bat 保持一致） ────────────────────────────────
_SCRIPT_DIR          = Path(__file__).resolve().parent
_DEFAULT_RELEASE_DIR = Path("D:/Code/echo-yonder-web-release")
_DEFAULT_PORT        = 8765


def start_server(release_dir: Path, port: int) -> http.server.HTTPServer:
    """在 release_dir 下启动 HTTP 服务，返回 server 实例。"""
    os.chdir(release_dir)

    class _QuietHandler(http.server.SimpleHTTPRequestHandler):
        def log_message(self, format: str, *args: object) -> None:  # noqa: A002
            pass  # 静默日志

    server = http.server.HTTPServer(("127.0.0.1", port), _QuietHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    return server


def main():
    parser = argparse.ArgumentParser(
        description="启动本地服务器测试 Web 构建。"
    )
    parser.add_argument(
        "--port", type=int, default=_DEFAULT_PORT,
        help=f"本地服务器端口（默认：{_DEFAULT_PORT}）",
    )
    parser.add_argument(
        "--release-dir", type=str, default=str(_DEFAULT_RELEASE_DIR),
        help=f"Web 发行版目录（默认：{_DEFAULT_RELEASE_DIR}）",
    )
    args = parser.parse_args()

    release_dir = Path(args.release_dir).resolve()
    port        = args.port

    # ── 检查目录 ──────────────────────────────────────────────────────────────
    if not release_dir.is_dir():
        print(f"[ERROR] Web 发行版目录不存在: {release_dir}")
        print("        请先运行 tools/deploy_web.bat 完成打包。")
        sys.exit(1)

    if not (release_dir / "index.html").exists():
        print(f"[ERROR] {release_dir} 中未找到 index.html，请先完成 Web 打包。")
        sys.exit(1)

    # ── 启动服务器 ────────────────────────────────────────────────────────────
    print(f"\n[服务器] 在 {release_dir} 启动 HTTP 服务...")
    try:
        server = start_server(release_dir, port)
    except OSError as e:
        print(f"[ERROR] 无法在端口 {port} 启动服务器: {e}")
        print(f"        请尝试换用其他端口：python tools/test_web_build.py --port 9000")
        sys.exit(1)

    url       = f"http://127.0.0.1:{port}/"
    clear_url = f"{url}?clear_persistent=1"
    print(f"[服务器] 已启动：{url}")

    # ── 清除持久化数据并打开游戏 ──────────────────────────────────────────────
    print(f"[浏览器] 打开 {clear_url}（启动时清除一次持久化数据）")
    webbrowser.open(clear_url)

    print("\n[提示] 服务器运行中，按 Ctrl+C 停止。")
    try:
        server._BaseServer__is_shut_down.wait()  # type: ignore[attr-defined]
    except (KeyboardInterrupt, AttributeError):
        pass
    finally:
        server.shutdown()
        print("\n[服务器] 已关闭。")


if __name__ == "__main__":
    main()
