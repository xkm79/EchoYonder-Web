# Project Agent Entry

This repository keeps the RenPy game and the AI workflow files separate.

## Structure

- `game/`: RenPy game files.
- `Renpy_AI_Workflow/`: AI workflow files, tools, task templates, and local knowledge.

## Required Agent Rules

Before making changes, read and follow:

- `Renpy_AI_Workflow/AGENTS.md`

When checking local RenPy API notes, use:

- `Renpy_AI_Workflow/knowledge/renpy_api_index.json`
