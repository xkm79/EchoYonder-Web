# Ren'Py Web Test Workflow

## Project entry point

- Run `tools\deploy_and_test.bat` from the repository root.
- When launched by double-click, build or server failures pause the console so the first `[ERROR]` message remains visible.
- Keep Windows `.bat` entry points ASCII-only. `cmd.exe` can misparse UTF-8 batch files with non-ASCII comments or messages and execute line fragments as commands.
- `tools\deploy_web.bat --no-pause` builds and patches the Web distribution, then mirrors it to `D:\Code\echo-yonder-web-release`.
- The release directory must already contain `.git`. The mirror operation excludes that path and verifies it still exists afterward.
- `tools\test_web_build.py` serves the release on `http://127.0.0.1:8765/` and opens `?clear_persistent=1`.

## Persistent-data reset

- `game/scripts/web_test_reset.rpy` defines the `?clear_persistent=1` check, and `game/splashscreen.rpy` calls it from the `splashscreen` label after Ren'Py has completed its normal default-variable initialization.
- It removes the query parameter with `history.replaceState`, calls the same `persistent._clear()` method used by the settings screen, and persists the result with `renpy.save_persistent()`.
- Do not call `persistent._clear()` from an `init` block. The method internally executes default statements; calling it during initialization causes the normal startup pass to report variables such as `quick_menu` as receiving a default twice in developer mode. This project calls it from `splashscreen` rather than `before_main_menu` because the first-launch splash flow jumps directly into `preface`.
- A normal browser refresh does not clear again because the query parameter has already been removed. Running the test launcher again intentionally requests one new clear.
- Browser persistence remains external to the Web package and release repository. It is stored by the browser for the `http://127.0.0.1:8765` origin; changing the host or port selects a different browser storage origin.

## Verification

- Python scripts compile successfully with `python -m py_compile`.
- Ren'Py 8.5.2 lint passes with `python Renpy_AI_Workflow/tools/run_renpy.py`.
- Verified APIs: `persistent._clear()`, `renpy.save_persistent()`, `renpy.emscripten.run_script()`, and `renpy.emscripten.run_script_string()`.
