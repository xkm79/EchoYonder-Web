# RenPy Lint Notes

## 2026-05-07 - Non-breaking spaces in .rpy indentation

- Issue: Ren'Py 8.5.2 lexer can fail with `empty line` when `.rpy` indentation contains non-breaking spaces (`U+00A0`), especially around indented comment-only lines.
- Fix: Replace `U+00A0` indentation with normal ASCII spaces and keep label colons as ASCII `:`.
- Verified with: `python Renpy_AI_Workflow/tools/run_renpy.py`.
- Related files: `game/script.rpy`.
