# Ren'Py Web Progressive Download

## Project configuration

- File: `progressive_download.txt` in the project root.
- Rules use `+ <type> <path>` for on-demand download and `- <type> <path>` for inclusion in `game.zip`.
- Rules are evaluated from top to bottom; the first matching rule for the same type wins.
- Supported rule types are `image`, `music`, and `voice`.

## Echo Yonder layout

- Keep `game/gui/**` images in `game.zip` because the logo and menus use them at startup.
- Download other images on demand with `+ image game/**`.
- Keep `game/audio/sfx/**` in `game.zip`; progressive music placeholders are unsuitable for short, non-looping effects.
- Download `game/audio/bgm/**` as music.
- Download the character voice directories under `game/audio/` as voice.
- Ren'Py Web always handles supported video files as remote files; `progressive_download.txt` does not define a `video` rule type.

## Verification source

- Ren'Py 8.5.2 launcher implementation: `launcher/game/web.rpy`, `ProgressiveFilter`, `load_filters`, and `filters_match`.
- Ren'Py 8.5.2 documentation: `doc/web.html`, “Progressive Downloading”.
