---
name: renpy-voice-generation
description: Generate and attach RenPy dialogue voice files for Echo-Yonder using the local IndexTTS2 portable model. Use when adding voice statements to game/script.rpy, cloning character voices from local prompt mp3 files, continuing the audio naming convention, or maintaining game/audio voice_map.md files.
---

# RenPy Voice Generation

Use this skill for Echo-Yonder dialogue voice work.

## Project Paths

- RenPy script: `game/script.rpy`
- Audio root: `game/audio`
- Batch helper: `Renpy_AI_Workflow/tools/generate_script_voice.py`
- IndexTTS2 app: `D:\IndexTTS2-Win10-Portable\IndexTTS2-Win10-Portable\app`
- IndexTTS2 Python: `D:\IndexTTS2-Win10-Portable\IndexTTS2-Win10-Portable\runtime\python\python.exe`
- Voice prompt folder: `C:\Users\24650\Desktop\garbage`

## Character Mapping

- `szm` uses `男主音色.mp3`
- `szm` questions ending in `？` or `?` use `男主疑问语气.mp3`
- `llr` uses `女主音色.mp3`
- `lmh` uses `男配音色.mp3`
- `unknown "可以进来吗？"` is treated as Lin Minghua and stored under `game/audio/lmh`
- `xty`, `terminal`, and `wbtb` use `系统音.mp3` and are stored under `game/audio/xty`

## Workflow

1. Read `Renpy_AI_Workflow/AGENTS.md`, then run `git status --short`.
2. Preview missing static role dialogue:
   ```powershell
   python Renpy_AI_Workflow/tools/generate_script_voice.py --dry-run
   ```
3. Generate missing wav files with the portable IndexTTS2 Python:
   ```powershell
   D:\IndexTTS2-Win10-Portable\IndexTTS2-Win10-Portable\runtime\python\python.exe Renpy_AI_Workflow/tools/generate_script_voice.py --generate
   ```
4. Insert `voice "audio/<role>/<file>.wav"` before each generated dialogue and write maps:
   ```powershell
   python Renpy_AI_Workflow/tools/generate_script_voice.py --patch-script --write-maps
   ```
5. Verify coverage and paths:
   ```powershell
   python Renpy_AI_Workflow/tools/generate_script_voice.py --verify
   ```
6. Run the project lint/smoke command:
   ```powershell
   python Renpy_AI_Workflow/tools/run_renpy.py
   ```

## Rules

- Only voice static character dialogue lines from `szm`, `llr`, `lmh`, `xty`, `terminal`, `unknown`, and `wbtb`.
- Skip narrator-only strings, UI/loading strings, empty dialogue, and dynamic player input such as `[answer]`.
- Continue the existing naming convention: `<role>_<chapter>_<seq>.wav`, for example `szm_01_18.wav`.
- Continue from the highest existing sequence in each role folder; never overwrite existing voice unless explicitly requested.
- Keep `voice_map.md` in each touched role folder with file name, script line, role, and text.
