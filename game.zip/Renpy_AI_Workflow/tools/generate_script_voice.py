from __future__ import annotations

import argparse
import os
import re
import subprocess
import sys
import time
import types
from dataclasses import dataclass
from pathlib import Path


START_LINE = 398
CHAPTER = "01"
SCRIPT_PATH = Path("game/script.rpy")
AUDIO_ROOT = Path("game/audio")
INDEXTTS_ROOT = Path(r"D:\IndexTTS2-Win10-Portable\IndexTTS2-Win10-Portable")
INDEXTTS_APP = INDEXTTS_ROOT / "app"
INDEXTTS_PYTHON = INDEXTTS_ROOT / "runtime" / "python" / "python.exe"
VOICE_SOURCE_ROOT = Path(r"C:\Users\24650\Desktop\garbage")

VOICE_RE = re.compile(r'^(?P<indent>\s*)voice\s+"(?P<path>[^"]+)"\s*$')
DIALOGUE_RE = re.compile(r'^(?P<indent>\s*)(?P<role>szm|llr|lmh|xty|terminal|unknown|wbtb)\s+"(?P<text>.*)"\s*$')
AUDIO_NAME_RE = re.compile(r"^(?P<prefix>[a-z]+)_(?P<chapter>\d{2})_(?P<seq>\d+)\.wav$", re.IGNORECASE)


VOICE_PROMPTS = {
    "szm": VOICE_SOURCE_ROOT / "男主音色.mp3",
    "szm_question": VOICE_SOURCE_ROOT / "男主疑问语气.mp3",
    "llr": VOICE_SOURCE_ROOT / "女主音色.mp3",
    "lmh": VOICE_SOURCE_ROOT / "男配音色.mp3",
    "xty": VOICE_SOURCE_ROOT / "系统音.mp3",
}

LOG_PATH: Path | None = None


def log(message: str) -> None:
    stamp = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{stamp}] {message}"
    print(line, flush=True)
    if LOG_PATH is not None:
        LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
        with LOG_PATH.open("a", encoding="utf-8") as handle:
            handle.write(line + "\n")


@dataclass
class Dialogue:
    index: int
    line_no: int
    indent: str
    role: str
    text: str
    output_role: str
    existing_voice: str | None
    assigned_voice: str | None = None
    prompt_key: str | None = None

    @property
    def voice_path(self) -> str | None:
        return self.existing_voice or self.assigned_voice


def output_role_for(role: str, text: str) -> str:
    if role in {"xty", "terminal", "wbtb"}:
        return "xty"
    if role == "unknown" and text == "可以进来吗？":
        return "lmh"
    return role


def prompt_key_for(output_role: str, text: str) -> str:
    if output_role == "szm" and text.rstrip().endswith(("？", "?")):
        return "szm_question"
    return output_role


def is_skipped_text(text: str) -> bool:
    stripped = text.strip()
    return not stripped or stripped == "[answer]"


def discover_next_sequences(repo_root: Path) -> dict[str, int]:
    next_seq = {"szm": 1, "llr": 1, "lmh": 1, "xty": 1}
    for role in next_seq:
        role_dir = repo_root / AUDIO_ROOT / role
        max_seq = 0
        if role_dir.exists():
            for file in role_dir.glob(f"{role}_{CHAPTER}_*.wav"):
                match = AUDIO_NAME_RE.match(file.name)
                if match and match.group("chapter") == CHAPTER:
                    max_seq = max(max_seq, int(match.group("seq")))
        next_seq[role] = max_seq + 1
    return next_seq


def collect_dialogues(repo_root: Path, assign_missing: bool = True) -> list[Dialogue]:
    lines = (repo_root / SCRIPT_PATH).read_text(encoding="utf-8").splitlines()
    next_seq = discover_next_sequences(repo_root)
    dialogues: list[Dialogue] = []

    for index, line in enumerate(lines):
        line_no = index + 1
        if line_no < START_LINE:
            continue
        match = DIALOGUE_RE.match(line)
        if not match:
            continue

        role = match.group("role")
        text = match.group("text")
        if is_skipped_text(text):
            continue

        output_role = output_role_for(role, text)
        if output_role not in next_seq:
            continue

        existing_voice = None
        if index > 0:
            voice_match = VOICE_RE.match(lines[index - 1])
            if voice_match:
                existing_voice = voice_match.group("path")

        dialogue = Dialogue(
            index=index,
            line_no=line_no,
            indent=match.group("indent"),
            role=role,
            text=text,
            output_role=output_role,
            existing_voice=existing_voice,
        )

        if assign_missing and existing_voice is None:
            seq = next_seq[output_role]
            next_seq[output_role] += 1
            filename = f"{output_role}_{CHAPTER}_{seq:02d}.wav"
            dialogue.assigned_voice = f"audio/{output_role}/{filename}"
            dialogue.prompt_key = prompt_key_for(output_role, text)

        dialogues.append(dialogue)

    return dialogues


def print_plan(dialogues: list[Dialogue]) -> None:
    missing = [d for d in dialogues if d.assigned_voice]
    existing = [d for d in dialogues if d.existing_voice]
    log(f"static voiced dialogues found: {len(dialogues)}")
    log(f"already voiced: {len(existing)}")
    log(f"missing voice: {len(missing)}")
    by_role: dict[str, int] = {}
    for dialogue in missing:
        by_role[dialogue.output_role] = by_role.get(dialogue.output_role, 0) + 1
    for role in sorted(by_role):
        log(f"  {role}: {by_role[role]}")
    for dialogue in missing:
        log(f"{dialogue.line_no}: {dialogue.role}->{dialogue.output_role} {dialogue.assigned_voice} {dialogue.text}")


def setup_indextts_environment() -> None:
    os.environ["HF_HUB_OFFLINE"] = "1"
    os.environ["TRANSFORMERS_OFFLINE"] = "1"
    os.environ["HF_HUB_CACHE"] = str(INDEXTTS_APP / "checkpoints" / "hf_cache")
    os.environ["HF_HOME"] = str(INDEXTTS_APP / "checkpoints" / "hf_home")
    os.environ["PYTHONNOUSERSITE"] = "1"
    os.environ["PATH"] = (
        str(INDEXTTS_ROOT / "runtime" / "python")
        + os.pathsep
        + str(INDEXTTS_ROOT / "runtime" / "python" / "Scripts")
        + os.pathsep
        + os.environ.get("PATH", "")
    )
    sys.path.insert(0, str(INDEXTTS_APP))
    install_librosa_filters_stub()
    install_bigvgan_meldataset_stub()


def install_librosa_filters_stub() -> None:
    module_name = "librosa.filters"
    if module_name in sys.modules:
        return

    def mel(*, sr, n_fft, n_mels=128, fmin=0.0, fmax=None, **_kwargs):
        import torchaudio

        n_freqs = int(n_fft // 2 + 1)
        f_max = float(fmax) if fmax is not None else float(sr) / 2.0
        basis = torchaudio.functional.melscale_fbanks(
            n_freqs=n_freqs,
            f_min=float(fmin),
            f_max=f_max,
            n_mels=int(n_mels),
            sample_rate=int(sr),
            norm="slaney",
            mel_scale="slaney",
        )
        return basis.transpose(0, 1).cpu().numpy()

    stub = types.ModuleType(module_name)
    stub.mel = mel
    sys.modules[module_name] = stub


def install_bigvgan_meldataset_stub() -> None:
    module_name = "indextts.s2mel.modules.bigvgan.meldataset"
    if module_name not in sys.modules:
        stub = types.ModuleType(module_name)
        stub.MAX_WAV_VALUE = 32767.0
        sys.modules[module_name] = stub


def patch_indextts_audio_loader(IndexTTS2) -> None:
    def _load_and_cut_audio(self, audio_path, max_audio_length_seconds, verbose=False, sr=None):
        import torch
        import torchaudio

        audio, original_sr = torchaudio.load(audio_path)
        if audio.shape[0] > 1:
            audio = audio.mean(dim=0, keepdim=True)
        target_sr = sr or original_sr
        if original_sr != target_sr:
            audio = torchaudio.transforms.Resample(original_sr, target_sr)(audio)
        max_audio_samples = int(max_audio_length_seconds * target_sr)
        if audio.shape[1] > max_audio_samples:
            if verbose:
                log(f"Audio too long ({audio.shape[1]} samples), truncating to {max_audio_samples} samples")
            audio = audio[:, :max_audio_samples]
        return audio.to(torch.float32), target_sr

    IndexTTS2._load_and_cut_audio = _load_and_cut_audio


def nvidia_smi_snapshot() -> str:
    try:
        completed = subprocess.run(
            ["nvidia-smi", "--query-gpu=memory.used,utilization.gpu", "--format=csv,noheader"],
            check=False,
            capture_output=True,
            text=True,
            timeout=10,
        )
        return completed.stdout.strip() or completed.stderr.strip()
    except Exception as exc:
        return f"nvidia-smi unavailable: {exc}"


def probe_runtime(import_indextts: bool = False, init_model: bool = False) -> None:
    setup_indextts_environment()
    log("probe: importing torch")
    import torch

    log(f"probe: torch cuda_available={torch.cuda.is_available()}")
    log(f"probe: torch cuda_device_count={torch.cuda.device_count()}")
    if torch.cuda.is_available():
        log(f"probe: torch cuda_device_0={torch.cuda.get_device_name(0)}")
    else:
        raise RuntimeError("CUDA is not available in the IndexTTS2 Python runtime.")

    if not import_indextts and not init_model:
        return

    log("probe: importing indextts.infer_v2")
    from indextts.infer_v2 import IndexTTS2
    patch_indextts_audio_loader(IndexTTS2)
    log("probe: imported indextts.infer_v2")

    if not init_model:
        return

    cwd = Path.cwd()
    os.chdir(INDEXTTS_APP)
    try:
        log("probe: initializing IndexTTS2 model")
        tts = IndexTTS2(
            model_dir="checkpoints",
            cfg_path="checkpoints/config.yaml",
            use_fp16=True,
            use_deepspeed=False,
            use_cuda_kernel=False,
            device="cuda:0",
        )
        log(f"probe: initialized IndexTTS2 device={tts.device}")
    finally:
        os.chdir(cwd)


def probe_import_modules() -> None:
    setup_indextts_environment()
    modules = [
        "librosa",
        "torch",
        "torchaudio",
        "omegaconf",
        "indextts.gpt.model_v2",
        "indextts.utils.maskgct_utils",
        "indextts.utils.checkpoint",
        "indextts.utils.front",
        "indextts.s2mel.modules.commons",
        "indextts.s2mel.modules.bigvgan.activations",
        "indextts.s2mel.modules.bigvgan.alias_free_activation.torch.act",
        "indextts.s2mel.modules.bigvgan.env",
        "indextts.s2mel.modules.bigvgan.meldataset",
        "indextts.s2mel.modules.bigvgan.utils",
        "indextts.s2mel.modules.bigvgan.bigvgan",
        "indextts.s2mel.modules.campplus.DTDNN",
        "indextts.s2mel.modules.audio",
        "transformers",
        "modelscope",
        "huggingface_hub",
        "safetensors",
    ]
    import importlib

    for module in modules:
        log(f"probe-imports: importing {module}")
        importlib.import_module(module)
        log(f"probe-imports: imported {module}")


def filter_dialogues(dialogues: list[Dialogue], line: int | None = None, limit: int | None = None) -> list[Dialogue]:
    selected = [d for d in dialogues if d.assigned_voice]
    if line is not None:
        selected = [d for d in selected if d.line_no == line]
    if limit is not None:
        selected = selected[:limit]
    return selected


def collect_missing_referenced_dialogues(repo_root: Path, line: int | None = None, limit: int | None = None) -> list[Dialogue]:
    dialogues = collect_dialogues(repo_root, assign_missing=False)
    selected: list[Dialogue] = []
    for dialogue in dialogues:
        if not dialogue.existing_voice:
            continue
        if line is not None and dialogue.line_no != line:
            continue
        output = repo_root / "game" / dialogue.existing_voice.replace("/", os.sep)
        if output.exists() and output.stat().st_size > 0:
            continue
        dialogue.assigned_voice = dialogue.existing_voice
        dialogue.prompt_key = prompt_key_for(dialogue.output_role, dialogue.text)
        selected.append(dialogue)
        if limit is not None and len(selected) >= limit:
            break
    return selected


def require_nonempty_wav(path: Path) -> None:
    if not path.exists():
        raise RuntimeError(f"Expected generated wav does not exist: {path}")
    if path.stat().st_size <= 0:
        raise RuntimeError(f"Generated wav is empty: {path}")


def generate_audio(
    repo_root: Path,
    dialogues: list[Dialogue],
    force: bool = False,
    line: int | None = None,
    limit: int | None = None,
    verbose_infer: bool = False,
) -> None:
    missing = filter_dialogues(dialogues, line=line, limit=limit)
    if not missing:
        log("No audio to generate.")
        return

    for prompt in VOICE_PROMPTS.values():
        if not prompt.exists():
            raise FileNotFoundError(f"Missing voice prompt: {prompt}")
    if not INDEXTTS_APP.exists():
        raise FileNotFoundError(f"Missing IndexTTS app: {INDEXTTS_APP}")

    setup_indextts_environment()

    log("generate: importing torch")
    import torch
    log(f"generate: torch cuda_available={torch.cuda.is_available()}")
    log(f"generate: torch cuda_device_count={torch.cuda.device_count()}")
    if torch.cuda.is_available():
        log(f"generate: torch cuda_device_0={torch.cuda.get_device_name(0)}")
    else:
        raise RuntimeError("CUDA is not available in the IndexTTS2 Python runtime.")

    log("generate: importing indextts.infer_v2")
    from indextts.infer_v2 import IndexTTS2
    patch_indextts_audio_loader(IndexTTS2)
    log("generate: imported indextts.infer_v2")

    cwd = Path.cwd()
    os.chdir(INDEXTTS_APP)
    try:
        log("generate: initializing IndexTTS2 model")
        tts = IndexTTS2(
            model_dir="checkpoints",
            cfg_path="checkpoints/config.yaml",
            use_fp16=True,
            use_deepspeed=False,
            use_cuda_kernel=False,
            device="cuda:0",
        )
        log(f"generate: initialized IndexTTS2 device={tts.device}")
        for pos, dialogue in enumerate(missing, 1):
            output = repo_root / "game" / dialogue.assigned_voice.replace("/", os.sep)
            output.parent.mkdir(parents=True, exist_ok=True)
            if output.exists() and not force:
                require_nonempty_wav(output)
                log(f"[{pos}/{len(missing)}] exists, skip {output}")
                continue
            prompt = VOICE_PROMPTS[dialogue.prompt_key or dialogue.output_role]
            log(f"[{pos}/{len(missing)}] generating {output.name}: {dialogue.text}")
            log(f"[{pos}/{len(missing)}] gpu before infer: {nvidia_smi_snapshot()}")
            started_at = time.perf_counter()
            tts.infer(
                spk_audio_prompt=str(prompt),
                text=dialogue.text,
                output_path=str(output),
                verbose=verbose_infer,
                max_text_tokens_per_segment=120,
                use_random=False,
            )
            require_nonempty_wav(output)
            elapsed = time.perf_counter() - started_at
            log(f"[{pos}/{len(missing)}] generated {output.name} ({output.stat().st_size} bytes) in {elapsed:.1f}s")
            log(f"[{pos}/{len(missing)}] gpu after infer: {nvidia_smi_snapshot()}")
    finally:
        os.chdir(cwd)


def patch_script(repo_root: Path, dialogues: list[Dialogue]) -> None:
    script = repo_root / SCRIPT_PATH
    lines = script.read_text(encoding="utf-8").splitlines()
    inserts = {d.index: d for d in dialogues if d.assigned_voice}
    new_lines: list[str] = []
    for index, line in enumerate(lines):
        dialogue = inserts.get(index)
        if dialogue:
            new_lines.append(f'{dialogue.indent}voice "{dialogue.assigned_voice}"')
        new_lines.append(line)
    script.write_text("\n".join(new_lines) + "\n", encoding="utf-8")


def write_voice_maps(repo_root: Path, dialogues: list[Dialogue]) -> None:
    grouped: dict[str, list[Dialogue]] = {}
    for dialogue in dialogues:
        if dialogue.voice_path:
            grouped.setdefault(dialogue.output_role, []).append(dialogue)

    for role, items in grouped.items():
        path = repo_root / AUDIO_ROOT / role / "voice_map.md"
        path.parent.mkdir(parents=True, exist_ok=True)
        rows = [
            "# Voice Map",
            "",
            "| file | script line | role | text |",
            "|---|---:|---|---|",
        ]
        for item in sorted(items, key=lambda d: d.voice_path or ""):
            filename = Path(item.voice_path or "").name
            text = item.text.replace("|", "\\|")
            rows.append(f"| {filename} | {item.line_no} | {item.role} | {text} |")
        path.write_text("\n".join(rows) + "\n", encoding="utf-8")


def verify(repo_root: Path) -> int:
    failures: list[str] = []
    lines = (repo_root / SCRIPT_PATH).read_text(encoding="utf-8").splitlines()

    for index, line in enumerate(lines):
        line_no = index + 1
        if line_no < START_LINE:
            continue
        match = DIALOGUE_RE.match(line)
        if not match:
            continue
        text = match.group("text")
        if is_skipped_text(text):
            continue
        if index == 0 or not VOICE_RE.match(lines[index - 1]):
            failures.append(f"Missing voice before line {line_no}: {line.strip()}")

    for line_no, line in enumerate(lines, 1):
        match = VOICE_RE.match(line)
        if not match:
            continue
        voice_path = repo_root / "game" / match.group("path").replace("/", os.sep)
        if not voice_path.exists():
            failures.append(f"Voice path missing at line {line_no}: {match.group('path')}")
        elif voice_path.stat().st_size <= 0:
            failures.append(f"Voice path is empty at line {line_no}: {match.group('path')}")

    for role in ["szm", "llr", "lmh", "xty"]:
        map_path = repo_root / AUDIO_ROOT / role / "voice_map.md"
        if not map_path.exists():
            failures.append(f"Missing voice map: {map_path}")

    if failures:
        for failure in failures:
            print(failure)
        return 1
    log("Voice verification passed.")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate and attach RenPy dialogue voice files.")
    parser.add_argument("--repo-root", default=".", help="Repository root.")
    parser.add_argument("--dry-run", action="store_true", help="Print the missing voice plan only.")
    parser.add_argument("--generate", action="store_true", help="Generate missing wav files.")
    parser.add_argument("--generate-referenced-missing", action="store_true", help="Generate missing wav files already referenced by voice statements.")
    parser.add_argument("--patch-script", action="store_true", help="Insert voice statements into script.rpy.")
    parser.add_argument("--write-maps", action="store_true", help="Write voice_map.md files.")
    parser.add_argument("--verify", action="store_true", help="Verify script voice coverage and file existence.")
    parser.add_argument("--force", action="store_true", help="Overwrite existing assigned output files.")
    parser.add_argument("--line", type=int, default=None, help="Only generate the missing dialogue at this script line.")
    parser.add_argument("--limit", type=int, default=None, help="Only generate the first N missing dialogues after filtering.")
    parser.add_argument("--verbose-infer", action="store_true", help="Print verbose IndexTTS2 internals during inference.")
    parser.add_argument("--log", default=None, help="Write progress logs to this UTF-8 file.")
    parser.add_argument("--probe-runtime", action="store_true", help="Probe torch/CUDA only.")
    parser.add_argument("--probe-import", action="store_true", help="Probe torch/CUDA and IndexTTS2 import.")
    parser.add_argument("--probe-model", action="store_true", help="Probe torch/CUDA, IndexTTS2 import, and model initialization.")
    parser.add_argument("--probe-imports", action="store_true", help="Probe each heavy infer_v2 dependency import separately.")
    args = parser.parse_args()

    global LOG_PATH
    if args.log:
        LOG_PATH = Path(args.log).resolve()
        LOG_PATH.write_text("", encoding="utf-8")

    repo_root = Path(args.repo_root).resolve()
    dialogues = collect_dialogues(repo_root, assign_missing=True)

    if args.probe_runtime or args.probe_import or args.probe_model:
        probe_runtime(import_indextts=args.probe_import or args.probe_model, init_model=args.probe_model)
    if args.probe_imports:
        probe_import_modules()
    if args.dry_run:
        print_plan(dialogues)
    if args.generate_referenced_missing:
        referenced = collect_missing_referenced_dialogues(repo_root, line=args.line, limit=args.limit)
        generate_audio(
            repo_root,
            referenced,
            force=args.force,
            line=None,
            limit=None,
            verbose_infer=args.verbose_infer,
        )
    elif args.generate:
        generate_audio(
            repo_root,
            dialogues,
            force=args.force,
            line=args.line,
            limit=args.limit,
            verbose_infer=args.verbose_infer,
        )
    if args.patch_script:
        patch_script(repo_root, dialogues)
    if args.write_maps:
        write_voice_maps(repo_root, dialogues)
    if args.verify:
        return verify(repo_root)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
