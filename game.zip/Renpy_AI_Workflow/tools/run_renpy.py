import subprocess
import os
import sys

REN_PY_PATH = r"D:\renpy-8.5.2-sdk\renpy.exe"  # 改成你的路径
PROJECT_DIR = os.getcwd()

def run_lint():
    cmd = [REN_PY_PATH, PROJECT_DIR, "lint"]
    result = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    return result.stdout, result.stderr

if __name__ == "__main__":
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")

    out, err = run_lint()
    print(out)
    print(err)
