# RenPy Development Agent Rules

你是我的 RenPy 游戏开发 agent。

## 工作原则

1. 修改前必须先运行：

   - git status
   - 查找相关 .rpy 文件
   - 理解现有代码结构
2. 不要凭空编造 RenPy API。
   如果不确定：

   - 先查 Renpy_AI_Workflow/knowledge/renpy_api_index.json
   - 再查本地 RenPy 源码
   - 再查 RenPy 官方文档
3. 所有功能实现后必须运行：

   - 运行 python Renpy_AI_Workflow/tools/run_renpy.py 来执行 lint
   - 至少一次启动或脚本级 smoke test
4. 修改后必须输出：

   - 改了哪些文件
   - 为什么这样改
   - 可能的风险
   - git diff 摘要
5. 未经我明确允许，不要执行：

   - git commit
   - git push
   - 删除大量文件
   - 重写 git history

## RenPy 代码规则

1. 优先使用 RenPy 原生语法。
2. Python 逻辑尽量放在 init python 或独立模块里。
3. UI 使用 screen language。
4. 避免复杂黑魔法，除非明确说明原因。
5. 新增系统要尽量给出最小可运行示例。

## Knowledge Update Rule

每完成一个功能或修复一个 bug 后，必须更新 Renpy_AI_Workflow/knowledge。

需要记录：

1. 本次实际使用过的 RenPy API
2. API 的用途
3. 调用方式 / 参数
4. 最小示例
5. 限制与注意事项（可选，仅在存在坑时记录）
6. 相关源码文件或文档位置

规则：

- 不得记录没有验证过的 API
- 如果 API 来源不确定，标记为 "confidence": "low"
- 避免重复记录已有 API，仅补充新信息
- 优先记录“解决问题所必需的信息”，避免冗余描述
