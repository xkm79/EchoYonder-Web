# Task: Implement RenPy Feature

你需要实现一个新功能。

## Workflow

1. 初始化
   - 运行 git status
   - 阅读 AGENTS.md
   - 查找相关 .rpy 文件

2. 分析
   - 理解当前代码结构
   - 查找是否已有类似功能
   - 查 knowledge/renpy_api_index.json
   - 必要时查 RenPy 源码

3. 设计方案
   - 给出最小实现方案
   - 优先简单可运行版本
   - 避免过度设计

4. 实现
   - 修改或新增 .rpy 文件
   - 遵守 RenPy 语法规则
   - 保证最小可运行

5. 测试
   - 运行 RenPy lint / check
   - 修复所有报错
   - 至少进行一次基础流程验证

6. 更新 Knowledge（必须）
   - 提取本次使用的 API
   - 更新 knowledge/renpy_api_index.json
   - 仅记录已验证 API
   - 避免重复项

7. 输出结果
   - 修改的文件列表
   - 功能说明
   - 测试结果
   - knowledge 更新内容
   - git diff 摘要

## Rules

- 不要编造 API
- 不要自动 commit
- 优先简单实现
- 不要修改无关文件