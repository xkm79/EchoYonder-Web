# Task: Fix RenPy Error

你需要修复一个错误或异常。

## Workflow

1. 初始化

   - 运行 git status
   - 阅读 Renpy_AI_Workflow/AGENTS.md
2. 分析错误

   - 阅读报错信息
   - 定位错误文件和行号
   - 找到相关 .rpy 代码
3. 原因分析

   - 判断错误类型：
     - 语法错误
     - API 使用错误
     - 逻辑错误
   - 查 Renpy_AI_Workflow/knowledge/renpy_api_index.json
   - 必要时查 RenPy 源码
4. 修复

   - 提供最小修改方案
   - 修改代码
   - 避免影响其他逻辑
5. 验证

   - 重新运行 Renpy_AI_Workflow\tools\run_renpy.py 来执行 lint
   - 确认错误消失
   - 检查是否引入新错误
6. 更新 Knowledge（可选）

   - 如果涉及 API 使用错误：
     - 更新 Renpy_AI_Workflow/knowledge/renpy_api_index.json 的 notes
   - 如果是典型错误：
     - 记录到 Renpy_AI_Workflow/knowledge/renpy_patterns.md
7. 输出结果

   - 错误原因
   - 修改内容
   - 修复说明
   - 测试结果
   - git diff 摘要

## Rules

- 不要大范围重构
- 优先最小修复
- 不要猜测错误原因，必须基于代码
- 不要自动 commit
