import os

import uvicorn
from dotenv import load_dotenv


load_dotenv()

deepseek_configured = bool(os.getenv("DEEPSEEK_API_KEY"))
volcengine_configured = bool(
    os.getenv("VOLCENGINE_ACCESS_KEY_ID")
    and os.getenv("VOLCENGINE_SECRET_ACCESS_KEY")
)
if not deepseek_configured and not volcengine_configured:
    raise SystemExit(
        "Configure DEEPSEEK_API_KEY or both VOLCENGINE_ACCESS_KEY_ID and "
        "VOLCENGINE_SECRET_ACCESS_KEY in backend/.env."
    )

uvicorn.run("app:app", host="127.0.0.1", port=8787)
