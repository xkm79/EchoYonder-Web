# Echo Yonder Local AI Proxy

This backend keeps the DeepSeek and VolcEngine credentials out of Ren'Py client code during local development.

## Setup

```powershell
cd backend
python -m pip install -r requirements.txt
Copy-Item .env.example .env
```

Edit `.env` and configure the providers you use:

```dotenv
DEEPSEEK_API_KEY=replace-with-your-new-deepseek-key

VOLCENGINE_ACCESS_KEY_ID=replace-with-your-volcengine-access-key
VOLCENGINE_SECRET_ACCESS_KEY=replace-with-your-volcengine-secret-key
```

The current VolcEngine visual API uses an AccessKey/SecretKey pair rather than a
single bearer token. Keep both values only in `backend/.env`.

## Run

```powershell
.\.venv\Scripts\python.exe run.py
```

Start the backend before launching the Ren'Py game. The game calls:

```text
http://127.0.0.1:8787/api/chat
http://127.0.0.1:8787/api/images/volcengine/request
```

## Health Check

```powershell
Invoke-RestMethod http://127.0.0.1:8787/health
```

The health response reports whether DeepSeek and VolcEngine credentials are
configured without exposing their values.
