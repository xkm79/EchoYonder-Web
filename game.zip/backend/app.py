import hashlib
import hmac
import json
import os
import time
from pathlib import Path
from typing import Any, Literal
from urllib.parse import quote, urlparse

import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field


ROOT_DIR = Path(__file__).resolve().parents[1]
BACKEND_DIR = Path(__file__).resolve().parent
load_dotenv(BACKEND_DIR / ".env")

PROMPTS_JSON_PATH = ROOT_DIR / "game" / "jsonfiles" / "prompts.json"
PROMPTS_DIR = ROOT_DIR / "game" / "prompts"

DEFAULT_SYSTEM_PROMPT = "请以一个温柔的角色回答用户的问题。"
DEFAULT_MODEL = "deepseek-chat"
DEFAULT_BASE_URL = "https://api.deepseek.com"
DEFAULT_VOLCENGINE_ENDPOINT = "https://visual.volcengineapi.com"
DEFAULT_VOLCENGINE_REGION = "cn-north-1"
DEFAULT_VOLCENGINE_SERVICE = "cv"
DEFAULT_VOLCENGINE_VERSION = "2022-08-31"
VOLCENGINE_IMAGE_ACTIONS = {
    "CVSync2AsyncSubmitTask",
    "CVSync2AsyncGetResult",
}


class ChatRequest(BaseModel):
    user_question: str = Field(..., min_length=1, max_length=1000)
    character_name: str = Field(default="default", max_length=80)
    memory_context: str = Field(default="", max_length=4000)
    isjson: bool = False


class ChatResponse(BaseModel):
    content: str


class VolcEngineImageRequest(BaseModel):
    action: Literal["CVSync2AsyncSubmitTask", "CVSync2AsyncGetResult"]
    body: dict[str, Any]


class VolcEngineImageResponse(BaseModel):
    ok: bool
    data: dict[str, Any] = Field(default_factory=dict)
    error: str = ""


app = FastAPI(title="Echo Yonder AI Proxy")

# 浏览器不能安全保存 DeepSeek/火山引擎密钥，因此 Web 游戏只调用本服务；
# 本服务再携带环境变量中的密钥访问上游 AI。整体调用链见：
# Ren'Py -> web_custom/ai_bridge.js -> 本 FastAPI 服务 -> 上游 AI。
_DEFAULT_CORS_ORIGINS = [
    "http://127.0.0.1",
    "http://127.0.0.1:8000",
    "http://127.0.0.1:8787",
    "http://localhost",
    "http://localhost:8000",
    "http://localhost:8787",
]


def _get_cors_origins() -> list[str]:
    """读取允许跨域调用本服务的网站地址。

    ALLOWED_ORIGINS 可填写逗号分隔的多个地址。星号能解决跨域限制，但它不提供
    身份认证或费用保护；公开部署时应优先填写实际的 Web 游戏域名。
    """
    extra = os.getenv("ALLOWED_ORIGINS", "")
    if extra.strip() == "*":
        return ["*"]
    extras = [o.strip().rstrip("/") for o in extra.split(",") if o.strip()]
    return list(dict.fromkeys(_DEFAULT_CORS_ORIGINS + extras))


_cors_origins = _get_cors_origins()
app.add_middleware(
    CORSMiddleware,
    allow_origins=_cors_origins,
    allow_credentials=False,
    allow_methods=["POST", "GET", "OPTIONS"],
    allow_headers=["Content-Type"],
)


def load_prompts_config() -> dict[str, Any]:
    try:
        with PROMPTS_JSON_PATH.open("r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def load_json_prompt_template(character_name: str) -> str:
    file_path = PROMPTS_DIR / "{}_prompt.txt".format(character_name)
    try:
        return file_path.read_text(encoding="utf-8")
    except Exception:
        return ""


def build_prompt_from_config(
    character_config: dict[str, Any],
    character_name: str = "",
    memory_context: str = "",
    is_json: bool = False,
) -> str:
    if not character_config:
        return DEFAULT_SYSTEM_PROMPT

    name = character_config.get("name", "角色")
    desc = character_config.get("description", "")
    parts = [
        "你是{}，{}。请以{}的身份和语气回答用户的问题。".format(name, desc, name)
    ]

    personality = character_config.get("personality", [])
    if personality:
        parts.append("\n【你的性格特点】")
        for trait in personality:
            parts.append("- {}".format(trait))

    if memory_context:
        parts.append("\n【你的记忆】\n{}".format(memory_context))

    rules = character_config.get("rules", [])
    if rules:
        parts.append("\n【重要规则】")
        for i, rule in enumerate(rules, 1):
            parts.append("{}. {}".format(i, rule))

    if is_json and character_name:
        template = load_json_prompt_template(character_name)
        if template:
            parts.append(template)

    return "\n".join(parts)


def get_prompt(character_name: str, memory_context: str = "", is_json: bool = False) -> str:
    config = load_prompts_config()
    character_config = config.get(character_name) or config.get("default", {})
    return build_prompt_from_config(
        character_config=character_config,
        character_name=character_name,
        memory_context=memory_context,
        is_json=is_json,
    )


def sha256_hex(value: str | bytes) -> str:
    if isinstance(value, str):
        value = value.encode("utf-8")
    return hashlib.sha256(value).hexdigest()


def hmac_sha256(key: bytes, value: str) -> bytes:
    return hmac.new(key, value.encode("utf-8"), hashlib.sha256).digest()


def volcengine_canonical_query(params: dict[str, str]) -> str:
    return "&".join(
        "{}={}".format(
            quote(str(key), safe="-_.~"),
            quote(str(params[key]), safe="-_.~"),
        )
        for key in sorted(params)
    )


def volcengine_authorization(
    method: str,
    host: str,
    path: str,
    query_params: dict[str, str],
    body_text: str,
    access_key: str,
    secret_key: str,
    region: str,
    service: str,
) -> tuple[str, str]:
    x_date = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())
    short_date = x_date[:8]
    canonical_headers = "content-type:application/json\nhost:{}\nx-date:{}\n".format(
        host,
        x_date,
    )
    signed_headers = "content-type;host;x-date"
    canonical_request = "{}\n{}\n{}\n{}\n{}\n{}".format(
        method,
        path,
        volcengine_canonical_query(query_params),
        canonical_headers,
        signed_headers,
        sha256_hex(body_text),
    )
    credential_scope = "{}/{}/{}/request".format(short_date, region, service)
    string_to_sign = "HMAC-SHA256\n{}\n{}\n{}".format(
        x_date,
        credential_scope,
        sha256_hex(canonical_request),
    )

    k_date = hmac_sha256(secret_key.encode("utf-8"), short_date)
    k_region = hmac_sha256(k_date, region)
    k_service = hmac_sha256(k_region, service)
    k_signing = hmac_sha256(k_service, "request")
    signature = hmac.new(
        k_signing,
        string_to_sign.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()
    authorization = (
        "HMAC-SHA256 Credential={}/{}, SignedHeaders={}, Signature={}".format(
            access_key,
            credential_scope,
            signed_headers,
            signature,
        )
    )
    return authorization, x_date


async def call_deepseek(request: ChatRequest) -> str:
    # 密钥只从后端环境变量读取，绝不能下发到 Ren'Py 包或浏览器 JavaScript。
    api_key = os.getenv("DEEPSEEK_API_KEY")
    if not api_key:
        raise HTTPException(
            status_code=500,
            detail="DEEPSEEK_API_KEY is not configured on the local backend.",
        )

    base_url = os.getenv("DEEPSEEK_BASE_URL", DEFAULT_BASE_URL).rstrip("/")
    model = os.getenv("DEEPSEEK_MODEL", DEFAULT_MODEL)
    messages = [
        {
            "role": "system",
            "content": get_prompt(
                request.character_name,
                memory_context=request.memory_context,
                is_json=request.isjson,
            ),
        },
        {"role": "user", "content": request.user_question},
    ]

    payload: dict[str, Any] = {
        "model": model,
        "messages": messages,
        "stream": False,
    }
    if request.isjson:
        payload["response_format"] = {"type": "json_object"}

    headers = {
        "Authorization": "Bearer {}".format(api_key),
        "Content-Type": "application/json",
    }

    try:
        # httpx 的 async 调用不会在等待 DeepSeek 时阻塞 FastAPI 的其他请求。
        async with httpx.AsyncClient(timeout=40) as client:
            response = await client.post(
                "{}/v1/chat/completions".format(base_url),
                headers=headers,
                json=payload,
            )
    except httpx.HTTPError as exc:
        raise HTTPException(status_code=502, detail="DeepSeek request failed.") from exc

    if response.status_code != 200:
        raise HTTPException(
            status_code=response.status_code,
            detail="DeepSeek returned an error.",
        )

    try:
        data = response.json()
        return data["choices"][0]["message"]["content"]
    except (KeyError, IndexError, TypeError, json.JSONDecodeError) as exc:
        raise HTTPException(status_code=502, detail="Invalid DeepSeek response.") from exc


async def call_volcengine_image(
    request: VolcEngineImageRequest,
) -> VolcEngineImageResponse:
    if request.action not in VOLCENGINE_IMAGE_ACTIONS:
        return VolcEngineImageResponse(ok=False, error="Unsupported VolcEngine action.")

    access_key = os.getenv("VOLCENGINE_ACCESS_KEY_ID", "")
    secret_key = os.getenv("VOLCENGINE_SECRET_ACCESS_KEY", "")
    if not access_key or not secret_key:
        return VolcEngineImageResponse(
            ok=False,
            error=(
                "VOLCENGINE_ACCESS_KEY_ID or VOLCENGINE_SECRET_ACCESS_KEY "
                "is not configured on the local backend."
            ),
        )

    endpoint = os.getenv(
        "VOLCENGINE_IMAGE_ENDPOINT",
        DEFAULT_VOLCENGINE_ENDPOINT,
    ).rstrip("/")
    region = os.getenv("VOLCENGINE_REGION", DEFAULT_VOLCENGINE_REGION)
    service = os.getenv("VOLCENGINE_SERVICE", DEFAULT_VOLCENGINE_SERVICE)
    version = os.getenv("VOLCENGINE_IMAGE_VERSION", DEFAULT_VOLCENGINE_VERSION)
    parsed = urlparse(endpoint)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        return VolcEngineImageResponse(
            ok=False,
            error="VOLCENGINE_IMAGE_ENDPOINT is invalid.",
        )

    host = parsed.netloc
    path = parsed.path or "/"
    query_params = {"Action": request.action, "Version": version}
    query_text = volcengine_canonical_query(query_params)
    url = "{}://{}{}?{}".format(parsed.scheme, host, path, query_text)
    body_text = json.dumps(
        request.body,
        ensure_ascii=False,
        separators=(",", ":"),
    )
    authorization, x_date = volcengine_authorization(
        method="POST",
        host=host,
        path=path,
        query_params=query_params,
        body_text=body_text,
        access_key=access_key,
        secret_key=secret_key,
        region=region,
        service=service,
    )
    headers = {
        "Authorization": authorization,
        "Content-Type": "application/json",
        "Host": host,
        "X-Date": x_date,
    }

    try:
        async with httpx.AsyncClient(timeout=90) as client:
            response = await client.post(
                url,
                headers=headers,
                content=body_text.encode("utf-8"),
            )
    except httpx.HTTPError:
        return VolcEngineImageResponse(
            ok=False,
            error="VolcEngine image request failed.",
        )

    try:
        data = response.json()
    except json.JSONDecodeError:
        return VolcEngineImageResponse(
            ok=False,
            error="VolcEngine returned an invalid response.",
        )

    if response.status_code != 200:
        return VolcEngineImageResponse(
            ok=False,
            data=data if isinstance(data, dict) else {},
            error="VolcEngine image API returned HTTP {}.".format(
                response.status_code
            ),
        )
    if not isinstance(data, dict):
        return VolcEngineImageResponse(
            ok=False,
            error="VolcEngine returned an invalid response.",
        )
    if data.get("code") not in (None, 0, 10000):
        return VolcEngineImageResponse(
            ok=False,
            data=data,
            error="VolcEngine image API returned an error.",
        )
    return VolcEngineImageResponse(ok=True, data=data)


@app.api_route("/", methods=["GET", "HEAD"])
async def root() -> dict[str, str]:
    # Render 等平台会访问根路径判断服务是否已启动。
    return {"message": "Echo Yonder AI Proxy is running."}


@app.get("/health")
async def health() -> dict[str, str | bool]:
    # 这里只返回“是否已配置”，不会泄露密钥本身。
    return {
        "status": "ok",
        "deepseek_configured": bool(os.getenv("DEEPSEEK_API_KEY")),
        "volcengine_configured": bool(
            os.getenv("VOLCENGINE_ACCESS_KEY_ID")
            and os.getenv("VOLCENGINE_SECRET_ACCESS_KEY")
        ),
    }


@app.post("/api/chat", response_model=ChatResponse)
async def chat(request: ChatRequest) -> ChatResponse:
    content = await call_deepseek(request)
    return ChatResponse(content=content)


@app.post(
    "/api/images/volcengine/request",
    response_model=VolcEngineImageResponse,
)
async def volcengine_image_request(
    request: VolcEngineImageRequest,
) -> VolcEngineImageResponse:
    return await call_volcengine_image(request)
